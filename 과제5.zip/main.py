import random
import datetime
import copy

#====================== 중복확인 함수 ======================#
def sorted(arr,w):
    for i in range(len(arr)-1):
        if arr[i][w] > arr[i+1][w]:
            return print("정렬 되지않았습니다.\n")
    print("정렬 되었습니다.\n")

#====================== 학생 정보 생성 ======================#
students=[]
N=20000 #학생 수

Alphabet=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
year=["2019","2020","2021","2022"]
number=[i for i in range(1000,10000)]

for i in range(4):
    a = 9000
    for j in range(5000):
        year_c =random.randint(0,3)
        id = [0, 0, 0]  # 한 학생의 학번, 이름, 핸드폰 번호
        y = year[year_c]
        b=random.randint(0,a-1)
        nn=str(number[b])
        id_n=y+nn
        number[b],number[a-1]=number[a-1],number[b]
        a-=1

        n=""     #이름
        for j in range(10):
            w= random.randint(0,25)
            l=Alphabet[w]
            n+=l

        p="010"   #전화번호
        for j in range(8):
            m=str(random.randint(0,9))
            p+=m

        id[0]=int(id_n)
        id[1]=n
        id[2]=p
        students.append(id)


#====================== 내장 함수 사용 정렬 ======================#
students_id=copy.deepcopy(students)
students_name=copy.deepcopy(students)

print("============내장함수 이용============")

print("(a-1) 내장함수 학번 순으로 정렬(오름차순)")
start_time=datetime.datetime.now()
students_id.sort
end_time=datetime.datetime.now()
time_id=end_time-start_time
print(time_id.microseconds/1000,"\n")


print("(a-2) 내장함수 이름 순으로 정렬(오름차순)")
start_time=datetime.datetime.now()
students_name.sort(key=lambda students_name:students_name[1])
end_time=datetime.datetime.now()
time_name=end_time-start_time
print(time_name.microseconds/1000,"\n")

#====================== 선택 정렬 ======================#
print("=========내가 입력한 코드 이용=========")

students_selection=copy.deepcopy(students)
def selection_sort(n,w):
    nl=len(n)
    for i in range(nl-1):
        least=i
        for j in range(i+1,nl):
            if n[j][w]<n[least][w]:
                least=j
        n[i],n[least]=n[least],n[i]

start_time=datetime.datetime.now()
selection_sort(students_selection,0)
end_time=datetime.datetime.now()
time_selection_1=end_time-start_time
print("(b-1) 선택정렬 학번 순으로 정렬(오름차순)")
print(time_selection_1.microseconds/1000)
sorted(students_selection,0)

start_time=datetime.datetime.now()
selection_sort(students_selection,1)
end_time=datetime.datetime.now()
time_selection_2=end_time-start_time
print("(b-2) 선택정렬 이름 순으로 정렬(오름차순)")
print(time_selection_2.microseconds/1000)
sorted(students_selection,1)
#====================== 퀵 정렬 ======================#
students_quick=copy.deepcopy(students)
def quick_sort(arr,w):
    def sort(low, high):
        if high <= low:
            return

        mid = partition(low, high)
        sort(low, mid - 1)
        sort(mid, high)

    def partition(low, high):
        pivot = arr[(low + high) // 2][w]
        while low <= high:
            while arr[low][w] < pivot:
                low += 1
            while arr[high][w] > pivot:
                high -= 1
            if low <= high:
                arr[low], arr[high] = arr[high], arr[low]
                low, high = low + 1, high - 1
        return low

    return sort(0, len(arr) - 1)

start_time=datetime.datetime.now()
quick_sort(students_quick,0)
end_time=datetime.datetime.now()
time_quick_1=end_time-start_time
print("(c-1) 퀵정렬 학번 순으로 정렬(오름차순)")
print(time_quick_1.microseconds/1000)
sorted(students_quick,0)

start_time=datetime.datetime.now()
quick_sort(students_quick,1)
end_time=datetime.datetime.now()
time_quick_2=end_time-start_time
print("(c-2) 퀵정렬 이름 순으로 정렬(오름차순)")
print(time_quick_2.microseconds/1000)
sorted(students_quick,1)
#====================== 힙 정렬 ======================#
students_heap=copy.deepcopy(students)

def adjust(a,i,size,w):
    while 2*i <= size:
        k=2*i
        if k < size and a[k-1][w] < a[k][w]:
            k+=1
        if a[i-1][w] < a[k-1][w]:
            a[i-1],a[k-1]=a[k-1],a[i-1]
        i=k

def heap_sort(a,w):
    hsize=len(a)
    for i in range(hsize//2,0,-1):
        adjust(a,i,hsize,w)

    for i in range(hsize,1,-1):
        a[0],a[i-1]=a[i-1],a[0]
        adjust(a,1,i-1,w)

start_time=datetime.datetime.now()
heap_sort(students_heap,0)
end_time=datetime.datetime.now()
time_heap_1=end_time-start_time
print("(d-1) 힙정렬 학번 순으로 정렬(오름차순)")
print(time_heap_1.microseconds/1000)
sorted(students_heap,0)


start_time=datetime.datetime.now()
heap_sort(students_heap,1)
end_time=datetime.datetime.now()
time_heap_2=end_time-start_time
print("(d-2) 힙정렬 이름 순으로 정렬(오름차순)")
print(time_heap_2.microseconds/1000)
sorted(students_heap,1)