from collections import defaultdict

INF=int(1e9)
print("노드개수, 간선의 개수를 입력하시오 >> ",end="")
n,e=map(int,input().split())
print("start? ",end="")
start=int(input())
print("end? ",end="")
end=int(input())

graph=[[]for i in range(n+1)] # 노드별로 연결된 노드 정보를 저장할 리스트 선언
visited=[False]*(n+1) # 방문 이력을 저장할 리스트
distance=[INF]*(n+1) # 최단 거리 테이블: 초기에는 모든 값을 무한으로 초기화

for _ in range(e): # 간선 정보를 입력받기
    print("출발점에서 도착점까지 가는 비용을 입력하시오.")
    n_a,n_b,cost=map(int,input().split())
    graph[n_a].append((n_b,cost))

#=============================================================================

def node_choice():  # 방문하지 않은 노드 중에서 가장 최단 거리가 짧은 노드 번호 반환
    min_v=INF
    idx=0  # 최단 거리가 가장 짧은 노드 번호(=인덱스)
    for i in range(1,n+1):
        if distance[i]<min_v and not visited[i]:
            min_v=distance[i]
            idx=i
    return idx

def dijstra(start): # 시작 노드의 최단 거리 및 방문이력 초기화
    for c in range(1, n + 1):
        if c != start:
            parents[c] = None   #parents는 딕셔너리임

    distance[start]=0
    visited[start]=True
    # 시작 노드와 연결된 각각의 노드 간의 거리
    for i in graph[start]:
        distance[i[0]]=i[1]

    for i in range(n-1): # 최단 거리가 가장 짧은 노드를 선택하고 방문처리
        n_now=node_choice()
        visited[n_now]=True
        for j in graph[n_now]: # 현재 노드를 거쳐 다른 노드까지의 거리 계산
            c=distance[n_now]+j[1]
            if c<distance[j[0]]: # 최단 거리 테이블 갱신 가능여부 체크
                distance[j[0]]=c


# 경로 추적을 위한 딕셔너리
parents = defaultdict()

dijstra(start)


if distance[end]==INF:
    print("INF")
else:
    print("거리는 %d"%distance[end])
