import copy

while True:
    # 목적지와 도착지를 설정
    print("시작점? ",end="")
    start=input()
    print("도착점? ",end="")
    end=input()


    graph = {
        '0': {'1':4,'2':8,'6':10},
        '1': {'0':4,'2':2,'3':5,'4':11},
        '2': {'0':8,'1':4,'4':9,'5':4,'6':5},
        '3': {'1':5,'4':7},
        '4': {'1':11,'2':9,'3':7,'5':2,'6':8},
        '5': {'2':4,'4':2},
        '6': {'0':10,'2':5,'4':8}
        }

    routing = {}
    for node in graph.keys():
        routing[node]={'shortestDist':0, 'route':[], 'visited':0}


    def visitPlace(visit):
        routing[visit]['visited'] = 1
        for toGo, betweenDist in graph[visit].items():
            toDist = routing[visit]['shortestDist'] + betweenDist
            if (routing[toGo]['shortestDist'] >= toDist) or  not routing[toGo]['route']:
                routing[toGo]['shortestDist'] = toDist
                routing[toGo]['route'] = copy.deepcopy(routing[visit]['route'])
                routing[toGo]['route'].append(visit)

    visitPlace(start)


    while True :
        minDist = max(routing.values(), key=lambda x:x['shortestDist'])['shortestDist']
        toVisit = ''
        for name, search in routing.items():
            if 0 < search['shortestDist'] <= minDist and not search['visited']:
                minDist = search['shortestDist']
                toVisit = name
        if toVisit == '':
            break
        visitPlace(toVisit)

    print("경로는 ",end="")
    for i in routing[end]['route']:
        print (i, end="-")
    print(end)
    print ("거리는", routing[end]['shortestDist'],"\n")
