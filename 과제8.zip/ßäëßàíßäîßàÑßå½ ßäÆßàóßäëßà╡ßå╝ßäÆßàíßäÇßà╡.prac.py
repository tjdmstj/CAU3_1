hash_table = [0 for i in range(24000)]

def hash_func(key):
    return key % 24000

def set_data(word,mean):
    hash_idx = hash(word)
    hash_key = hash_func(hash_idx)
    if hash_table[hash_key] != 0:
        for i in range(len(hash_table[hash_key])):
            if hash_table[hash_key][i][0] == hash_idx:
                hash_table[hash_key][i][1] = mean
                return True
        hash_table[hash_key].append([hash_idx,mean])
        return True
    else:
        hash_table[hash_key] = [[hash_idx,mean]]
        return True

def get_data(data):
    i=0
    hash_idx = hash(data)
    hash_key = hash_func(hash_idx)
    if hash_table[hash_key]:
        for value in hash_table[hash_key]:
            i+=1
            if value[0] == hash_idx:
                return value[1],i
        return None
    else:
        return None
#===========파일 읽어와서 해싱에 저장하기==================
f=open("randdict.TXT","r")
while True:
    line = f.readline()
    if not line:
        break
    list = line.split(":")
    word = list[0].strip()  # 앞뒤로 공백을 제거해준다.
    mean = list[1].strip()
    set_data(word,mean)
f.close()

j=1
max=0
for i in hash_table:
    if i==0:
        continue
    else:
        if len(i)>max:
            max=len(i)
    j+=1

print(max)