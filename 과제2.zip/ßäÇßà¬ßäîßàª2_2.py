#방식 2 - 0이 아닌 계수의 차수만 저장
def add(fl,sl):
    final=[]
    i=0
    j=0

    while True:
        if (first[i+1]==second[j+1]):
            final.append(first[i]+second[j])
            final.append(first[i+1])
            i+=2
            j+=2
        elif(first[i+1]>second[j+1]):
            final.append(first[i])
            final.append(first[i+1])
            i+=2
        else:
            final.append(second[j])
            final.append(second[j+1])
            j+=2
        if (i==fl and j==sl):
            break
        elif (i==fl):
            for h in range(j+1,sl,2):
                final.append(second[h])
                final.append(h)
                break
        elif (j==sl):
            for h in range(i+1,fl,2):
                final.append(first[h])
                final.append(h)
                break
    print("수식 1 + 2 는",end=" ")
    for i in final:
        print(i,end=" ")
    return final

def multiply(fl,sl):
    final=[]
    f=[]
    best=first[1]+second[1]

    for i in range(0,fl,2):
        for j in range(0,sl,2):
            final.append(first[i]*second[j])
            final.append(first[i+1]+second[j+1])

    for i in reversed(range(best+1)):      #ex) 5~0
        count=0
        for j in range(1,len(final),2):
            if (final[j]==i):
                count+=final[j-1]
        f.append(count)
        f.append(i)

    print("수식 1 * 2 는",end=" ")
    for i in f:
        print(i,end=" ")

    return f



a=input("수식 1을 입력하세요: ")
b=input("수식 2를 입력하세요: ")

a=a.split(" ")
b=b.split(" ")
first=[]
second=[]

for i in a:
    first.append(int(i))
for i in b:
    second.append(int(i))

fl,sl=len(first),len(second)
add=add(fl,sl)
print("\n")
multiply=multiply(fl,sl)
print("\n")
while True:
    put=input("수식에 값을 넣으세요")
    if (put=="end"):
        break
    else:
        put=put.split(" ")

        put_in=[]
        put_in.append(int(put[0]))
        put_in.append(int(put[1]))

        out=0
        if (put_in[0]==1):
            for i in range(1,len(first),2):
                out+=(put_in[1]**(first[i]))*first[i-1]
        elif(put_in[0]==2):
            for i in range(1,len(second),2):
                out+=(put_in[1]**(second[i]))*second[i-1]
        elif(put_in[0]==3):
            for i in range(1,len(add),2):
                out+=(put_in[1]**(add[i]))*add[i-1]
        elif(put_in[0]==4):
            for i in range(1,len(multiply),2):
                out+=(put_in[1]**(multiply[i]))*multiply[i-1]

        print("결과값은 %d"%out)