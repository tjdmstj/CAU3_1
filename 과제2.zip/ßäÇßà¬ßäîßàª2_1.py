#방식 1 - 모든 차수의 계수를 저장
def add(fl,sl):
    final = []
    if (fl>sl):
        for j in range(fl-sl):
            final.append(first[j])
        for j in range(sl):
            final.append(first[j+(fl-sl)]+second[j])
    elif (sl>fl):
        for j in range(sl-fl):
            final.append(second[j])
        for j in range(fl):
            final.append(first[j+(sl-fl)]+second[j])
    else:
        for j in range(fl):
            final.append(first[j]+second[j])

    print("수식 1+2 는 ",end="")
    for i in final:
        print(i,end=" ")

    return final

def multiply(fl,sl):
    final=[]
    num=[]
    f=[]
    max=fl+sl-2
    if (fl>sl):
        for i in range(fl):
            for j in range(sl):
                if(first[i]==0 or second[j]==0):
                    continue
                final.append(first[i]*second[j])
                num.append(max-(i+j))
    elif (sl>fl):
        for i in range(sl):
            for j in range(fl):
                if (first[i] == 0 or second[j] == 0):
                    continue
                final.append(first[i]*second[j])
                num.append(max-(j+i))
    else:
        for i in range(fl):
            for j in range(sl):
                if (first[i] == 0 or second[j] == 0):
                    continue
                final.append(first[i]*second[j])
                num.append(max-(i + j))
    final.append(num)

    for j in reversed(range(max+1)):                #ex) 5~0
        count = 0
        for i in range(len(final[-1])):       #ex) 5, 4, 3, 3, 2, 1, 2, 1, 0 /
            if (final[-1][i]==j):
                count+=final[i]
        f.append(count)

    print("수식 1*2 는 ",end="")
    for i in f:
        print(i,end=" ")

    return f

first=[]
second=[]
a=input("수식 1을 입력하세요: ")
b=input("수식 2를 입력하세요: ")

a=a.split(" ")
b=b.split(" ")

for i in a:
    first.append(int(i))
for i in b:
    second.append(int(i))
fl,sl=len(first),len(second)

add=add(fl,sl)
print("\n")
multiply=multiply(fl,sl)       ## 수식 프린트 하기
print("\n")

while True:
    put=input("수식에 값을 넣으세요")
    if (put=="end"):
        break
    else:
        put=put.split(" ")

        put_in=[]
        put_in.append(int(put[0]))
        put_in.append(int(put[1]))

        out=0
        if (put_in[0]==1):
            for i in range(len(first)):
                out+=(put_in[1]**(len(first)-i-1))*first[i]
        elif (put_in[0]==2):
            for i in range(len(second)):
                out+=(put_in[1]**(len(second)-i-1))*second[i]
        elif (put_in[0]==3):
            for i in range(len(add)):
                out+=(put_in[1]**(len(add)-i-1))*add[i]
        elif (put_in[0]==4):
            for i in range(len(multiply)):
                out+=(put_in[1]**(len(multiply)-i-1))*multiply[i]

        print("결과값은 %d"%out)