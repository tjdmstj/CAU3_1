class Node:
    def __init__(self,item,mean,left=None,right=None):
        self.item=item
        self.mean=mean
        self.left=left
        self.right=right

class BinaryTree:
    def __init__(self):
        self.root=None
        self.n=0


    def search(self,item):                #트리에 원하는 노드가 있는지 확인함
        self.n=0
        if self.root is None:
            return None
        else:
            return self.__search_node(self.root,item)

    def __search_node(self, cur, item):
        self.n+=1
        if cur is None:
            return None
        if cur.item == item:
            return cur.mean, self.n
        elif cur.item >= item:
            return self.__search_node(cur.left,item)
        else:
            return self.__search_node(cur.right,item)
        return None

    def insert(self,item,mean):                 #root에 노드가 있으면 왼쪽 혹은 오른쪽에 배치함
        if self.root is None:
            self.root=Node(item,mean)
        else:
            self.insert_node(self.root,item,mean)

    def insert_node(self,cur,item,mean):
        if cur.item>=item:      #root값이 크면 왼쪽으로 insert
            if cur.left is not None:   #왼쪽이 비어있지 않은 경우
                self.insert_node(cur.left,item,mean)
            else:
                cur.left=Node(item,mean)

        else:                 #root값이 작으면 오른쪽으로 insert
            if cur.right is not None:  #오른쪽이 비어있지 않은 경우
                self.insert_node(cur.right,item,mean)
            else:
                cur.right=Node(item,mean)


    def count(self):
        if self.root is not None:
            return self.count_node(self.root)
        else: return 0

    def count_node(self,n):  # node 개수 세기
        if n is None:
            return 0
        else:
            return 1 + self.count_node(n.left) + self.count_node(n.right)

    def calc_height_node(self):
        if self.root is not None:
            return self.calc_height(self.root)
        else: return 0

    def calc_height(self,n):
        if n is None:
            return 0
        else:
            return 1+max(self.calc_height(n.left),self.calc_height(n.right))
#==========================================================================#
f=open("randdict.TXT","r")
A = BinaryTree()
while True:
    line = f.readline()
    if not line:
        break
    list = line.split(":")
    word = list[0].strip()  # 앞뒤로 공백을 제거해준다.
    mean = list[1].strip()
    A.insert(word,mean)

f.close()

num= A.count()
height=A.calc_height_node()
print("사전 파일을 모두 읽었습니다. %d개의 단어가 있습니다."%num)
print("A 트리의 전체 높이는 %d 입니다. A 트리의 노드 수 는 %d개 입니다."%(height,num))

while True:
    word=input("단어를 입력하세요(빈칸을 입력하면 종료) >> ")
    if word=="":
        break
    else:
        a,level=A.search(word)
        print("%s (레벨%d)"%(a,level))




