class Node:
    def __init__(self,item,mean,left=None,right=None):
        self.item=item
        self.mean=mean
        self.left=left
        self.right=right

class BinaryTree:
    def __init__(self):
        self.root=None
        self.n=0

    def search(self,item,tree):                #트리에 원하는 노드가 있는지 확인함
        self.n=0
        self.root = tree
        if self.root is None:
            return None
        else:
            return self.__search_node(self.root,item)

    def __search_node(self, cur, item):
        self.n+=1
        if cur is None:
            return None
        if cur.item == item:
            return cur.mean, self.n
        elif cur.item >= item:
            return self.__search_node(cur.left,item)
        else:
            return self.__search_node(cur.right,item)
        return None


    def insert_n(self,W_list):     #리스트의 중앙이 부모노드가 되게 insert함
        if not W_list:
            return None
        mid=len(W_list)//2
        node=Node(W_list[mid][0],W_list[mid][1])

        node.left=self.insert_n(W_list[:mid])
        node.right=self.insert_n(W_list[mid+1:])

        return node

    def count(self,tree):
        self.root=tree
        if self.root is not None:
            return self.count_node(self.root)
        else: return 0

    def count_node(self,n):  # node 개수 세기
        if n is None:
            return 0
        else:
            return 1 + self.count_node(n.left) + self.count_node(n.right)

    def calc_height_node(self,tree):
        self.root = tree
        if self.root is not None:
            return self.calc_height(self.root)
        else: return 0

    def calc_height(self,n):
        if n is None:
            return 0
        else:
            return 1+max(self.calc_height(n.left),self.calc_height(n.right))

    def inorder(self,node):
        if node!=None:
            self.inorder(node.left)
            print(node.item)
            self.inorder(node.right)
#==========================================================================#
f=open("randdict.TXT","r")
B = BinaryTree()
W_list=[]
while True:
    line = f.readline()
    if not line:
        break
    list = line.split(":")
    word = list[0].strip()  # 앞뒤로 공백을 제거해준다.
    mean = list[1].strip()
    list=[word,mean]
    W_list.append(list)
f.close()

W_list.sort()   #word를 정렬시킴
tree=B.insert_n(W_list)  #B에 단어들을 넣음

num= B.count(tree)
height=B.calc_height_node(tree)
print("사전 파일을 모두 읽었습니다. %d개의 단어가 있습니다."%num)
print("B 트리의 전체 높이는 %d 입니다. B 트리의 노드 수 는 %d개 입니다."%(height,num))

while True:
    word=input("단어를 입력하세요(빈칸을 입력하면 종료) >> ")
    if word=="":
        break
    else:
        a,level=B.search(word,tree)
        print("%s (레벨%d)"%(a,level))