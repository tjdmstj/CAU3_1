def insert_n(self, W_list):  # 리스트의 중앙이 부모노드가 되게 insert함
    if not W_list:
        return None
    mid = len(W_list) // 2
    node = Node(W_list[mid][0], W_list[mid][1])

    node.left = self.insert_n(W_list[:mid])
    node.right = self.insert_n(W_list[mid + 1:])

    self.root = node