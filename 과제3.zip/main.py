#과제 3_1 계산기

class Stack:
    def __init__(self):
        self.stack=[]
        self.top=-1             # top 시작 위치 -1

    def push(self,num):
        self.stack.append(num)
        self.top+=1            # push하면 top 1씩 증가시킴

    def pop(self):
        if self.top!=-1:       # 만약 stack에 값이 들어 있다면 pop을 할 때 top -1
            self.top-=1
            return self.stack.pop()
        else:
            print("스택이 비었습니다.")


    def isEmpty(self):
        if self.top ==-1:
            return -1
        else:
            return 0

    def peek(self):                 #스택의 맨 위에 값 확인하기
        return self.stack[-1]
#=========================================================
def is_number(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

def change (math):                                          #입력받은 사칙연산 리스트에 저장하는 함수
    count=""
    diff=[]
    in_put=[]
    for i in math:
        if i not in "+-*/()":
            count+=i
        else:
            diff.append(count)
            diff.append(i)
            count=""
    if count!="":
        diff.append(count)


    for i in range(len(diff)):
        if diff[i] in "+-*/()":
            in_put.append(diff[i])
        elif is_number(diff[i]):
            in_put.append(diff[i])

    b = in_put.count("")

    for i in range(b):
        in_put.remove("")

    return in_put
#=========================================================
def toPostfix(in_put):                     #중위 표기법을 후위표기법으로 변경하는 함수
    priority = {"+": 1, "-": 1, "*": 2, "/": 2, "(":0}  # 우선 순위 설정(숫자가 높을 수록 높은 순위)
    out=[]
    s=Stack()
    for i in in_put:
        if (i == "("):
            s.push(i)
        elif (i == ")"):                   #")"이 나오면 "("부터 저장해 놓은 것들 차례대로 출력
            while s.isEmpty()==0:
                op=s.pop()
                if op=="(":
                    break
                else:
                    out.append(op)

        elif i in "+-*/":                     # i가 연산자인 경우 우선순위를 비교하여 출력할지 저장할지를 결정
            while s.isEmpty() == 0:              # i가 stack 맨 위에 저장되어 있는 연산자와 우선순위를 비교
               op=s.peek()
               if (priority[i] <= priority[op]):
                    out.append(op)
                    s.pop()
               else: break
            s.push(i)

        else:
            out.append(i)

    while s.isEmpty() == 0:
        out.append(s.pop())

    return out

#=========================================================
def Cal(cal):                                  #후위 표기법으로 사칙연산 계산하기
    s=Stack()
    for i in cal:
        if i in "+-/*":
            second=s.pop()                     #뒤에부터 수자 부터나옴
            first=s.pop()
            if i=="+":
                s.push(first+second)
            elif i=="-":
                s.push(first-second)
            elif i=="*":
                s.push(first*second)
            elif i=="/":
                s.push(first/second)
        else:
            s.push(float(i))
    return s.pop()


#======================================================== 오류 확인하는 함수 만들기
def correct(in_put):
    check=[]                                              #오류의 위치를 저장하는 리스트
    error_c=0                                             #괄호가 있는 체크하는 변수
    count=0
    for i in range(len(in_put)):
        if (in_put[i] == "("):
            count+=1
            error_c=1
            check.append(" ")
        elif in_put[i] in "+-/*":
            count+=1
            if in_put[i-1] in "+-/*":
                check.append("^")
                break
            else:check.append("  ")
        elif in_put[i]==")":
            count+=1
            if error_c==0:
                check.append("^")
                break
            else:
                error_c=0
                check.append(" ")

    if check.count("^")==0 and error_c==1:
        check.append("^ 이 위치에 오류가 있습니다.\n")
        return check
    elif check.count("^")>0:
        check.append(" 이 위치에 오류가 있습니다.\n")
        return check
    else:
        return 0

#=========================================================
while True:
    math=input("수식을 입력하세요.\n")
    if math=="end":
        break
    math=list(math)
    in_put=change(math)

    if correct(in_put)==0:
        out = toPostfix(in_put)
        final = Cal(out)
        print("=%f"%final)
    else:
        for i in correct(in_put):
            print(i,end="")
#=========================================================
