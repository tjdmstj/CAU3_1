#과제 3_2 열차 재배치(최종)

class Stack:
    def __init__(self):
        self.stack=[]
        self.top=-1             # top 시작 위치 -1

    def push(self, num):
        self.stack.append(num)
        self.top+=1            # push하면 top 1씩 증가시킴

    def pop(self):
        if self.top!=-1:       # 만약 stack에 값이 들어 있다면 pop을 할 때 top -1
            self.top-=1
            return self.stack.pop()
        else:
            print("스택이 비었습니다.")

    def isEmpty(self):
        if self.top ==-1:
            return -1
        else:
            return 0

    def peek(self):                        # 스택의 맨 위에 값 확인하기
        if not self.stack.__len__() == 0:
            return self.stack[-1]
        else:
            return 0                       # 빈칸이다

    def seek(self, n):             #스택안에 특정 숫자가 있는 파악하는 함수
        if n in self.stack:
            count = 0
            for i in self.stack:
                count+=1
                if i == n:
                    break
            return len(self.stack)-count+1
        else:
            return 0

    def __len__(self):
        return len(self.stack)
#============================================
number=input("스택의 개수: ")

if number=='2':
    s1 = Stack()
    s2 = Stack()
    train = list(input("열차 번호 입력: "))
    for i in range(len(train)):
        train[i] = int(train[i])
    n = 1
    count = 1  # 열차의 번호와 나갈 차례의 열차 번호와 같은 지 확인하는 변수
    i = 0
    while True:
        if i == len(train):
            while (count <= len(train)):
                if s1.seek(count) > 0:
                    if s1.seek(count) > 1:
                        for i in range(s1.seek(count) - 1):
                            num = s1.pop()
                            s2.push(num)
                            print("%d : POP(1)" % n)
                            n += 1
                            print("%d : PUSH(%d,%d)" % (n, 2, num))
                            n += 1
                    print("%d : POP(1)" % n)
                    n += 1
                    print("%d : OUT(%d)" % (n, s1.pop()))
                    n += 1
                    count += 1
                elif s2.seek(count) > 0:
                    if s2.seek(count) > 1:
                        for i in range(s2.seek(count) - 1):
                            num = s2.pop()
                            s1.push(num)
                            print("%d : POP(2)" % n)  # count가 나올때까지 s1로 옮기기
                            n += 1
                            print("%d : PUSH(%d,%d)" % (n, 1, num))
                            n += 1
                    print("%d : POP(2)" % n)
                    n += 1
                    print("%d : OUT(%d)" % (n, s2.pop()))
                    n += 1
                    count += 1
            break

        if (train[i] == count):
            print("%d : IN(%d)" % (n, train[i]))
            n += 1
            print("%d : OUT(%d)" % (n, train[i]))
            n += 1
            count += 1
            i += 1
            continue

        if i == 0:
            s1.push(train[i])
            print("%d : IN(%d)" % (n, train[0]))
            n += 1
            print("%d : PUSH(%d,%d)" % (n, 1, train[i]))
            n += 1
            i += 1
        else:
            if s1.seek(count) > 0:
                if s1.seek(count) > 1:
                    for i in range(s1.seek(count) - 1):
                        num = s1.pop()
                        s2.push(num)
                        print("%d : POP(1)" % n)
                        n += 1
                        print("%d : PUSH(%d,%d)" % (n, 2, num))
                        n += 1
                print("%d : POP(1)" % n)
                n += 1
                print("%d : OUT(%d)" % (n, s1.pop()))
                n += 1
                count += 1

            elif s2.seek(count) > 0:
                if s2.seek(count) > 1:
                    for i in range(s2.seek(count) - 1):
                        num = s2.pop()
                        s1.push(num)
                        print("%d : POP(2)" % n)
                        n += 1
                        print("%d : PUSH(%d,%d)" % (n, 1, num))
                        n += 1
                print("%d : POP(2)" % n)
                n += 1
                print("%d : OUT(%d)" % (n, s2.pop()))
                n += 1
                count += 1

            else:
                if train[i] > s1.peek():
                    s2.push(train[i])
                    print("%d : IN(%d)" % (n, train[i]))
                    n += 1
                    print("%d : PUSH(%d,%d)" % (n, 2, train[i]))
                    n += 1
                    i += 1
                else:
                    s1.push(train[i])
                    print("%d : IN(%d)" % (n, train[i]))
                    n += 1
                    print("%d : PUSH(%d,%d)" % (n, 1, train[i]))
                    n += 1
                    i += 1

    print("종료(총 %d회)" % (n - 1))
elif number=='3':
    s1 = Stack()
    s2 = Stack()
    s3 = Stack()

    train = list(input("열차 번호 입력: "))
    for i in range(len(train)):
        train[i] = int(train[i])

    n = 1
    count = 1  # 열차의 번호와 나갈 차례의 열차 번호와 같은 지 확인하는 변수
    i = 0
    while True:
        if i == len(train):
            while (count <= len(train)):
                if s1.seek(count) > 0:
                    if s1.seek(count) > 1:
                        for i in range(s1.seek(count) - 1):
                            num = s1.pop()
                            s2.push(num)
                            print("%d : POP(1)" % n)
                            n += 1
                            print("%d : PUSH(%d,%d)" % (n, 2, num))
                            n += 1
                    print("%d : POP(1)" % n)
                    n += 1
                    print("%d : OUT(%d)" % (n, s1.pop()))
                    n += 1
                    count += 1
                elif s2.seek(count) > 0:
                    if s2.seek(count) > 1:
                        for i in range(s2.seek(count) - 1):
                            num = s2.pop()
                            s1.push(num)
                            print("%d : POP(2)" % n)  # count가 나올때까지 s1로 옮기기
                            n += 1
                            print("%d : PUSH(%d,%d)" % (n, 1, num))
                            n += 1
                    print("%d : POP(2)" % n)
                    n += 1
                    print("%d : OUT(%d)" % (n, s2.pop()))
                    n += 1
                    count += 1
                elif s3.seek(count) > 0:
                    if s3.seek(count) > 1:
                        for i in range(s3.seek(count) - 1):
                            num = s3.pop()
                            s1.push(num)
                            print("%d : POP(3)" % n)  # count가 나올때까지 s1로 옮기기
                            n += 1
                            print("%d : PUSH(%d,%d)" % (n, 1, num))
                            n += 1
                    print("%d : POP(3)" % n)
                    n += 1
                    print("%d : OUT(%d)" % (n, s3.pop()))
                    n += 1
                    count += 1

            break

        if (train[i] == count):
            print("%d : IN(%d)" % (n, train[i]))
            n += 1
            print("%d : OUT(%d)" % (n, train[i]))
            n += 1
            count += 1
            i += 1
            continue

        if i == 0:
            s1.push(train[i])
            print("%d : IN(%d)" % (n, train[0]))
            n += 1
            print("%d : PUSH(%d,%d)" % (n, 1, train[i]))
            n += 1
            i += 1
        else:
            if s1.seek(count) > 0:
                if s1.seek(count) > 1:
                    for i in range(s1.seek(count) - 1):
                        num = s1.pop()
                        s2.push(num)
                        print("%d : POP(1)" % n)
                        n += 1
                        print("%d : PUSH(%d,%d)" % (n, 2, num))
                        n += 1
                print("%d : POP(1)" % n)
                n += 1
                print("%d : OUT(%d)" % (n, s1.pop()))
                n += 1
                count += 1

            elif s2.seek(count) > 0:
                if s2.seek(count) > 1:
                    for i in range(s2.seek(count) - 1):
                        num = s2.pop()
                        s1.push(num)
                        print("%d : POP(2)" % n)
                        n += 1
                        print("%d : PUSH(%d,%d)" % (n, 1, num))
                        n += 1
                print("%d : POP(2)" % n)
                n += 1
                print("%d : OUT(%d)" % (n, s2.pop()))
                n += 1
                count += 1
            elif s3.seek(count) > 0:
                if s3.seek(count) > 1:
                    for i in range(s3.seek(count) - 1):
                        num = s3.pop()
                        s1.push(num)
                        print("%d : PUSH(%d,%d)" % (n, 1, num))  # count가 나올때까지 s1로 옮기기
                        n += 1
                        print("%d : POP(3)" % n)
                        n += 1
                print("%d : POP(3)" % n)
                n += 1
                print("%d : OUT(%d)" % (n, s3.pop()))
                n += 1
                count += 1

            else:
                if train[i] > s1.peek():
                    if s2.__len__() <= s3.__len__():
                        s2.push(train[i])
                        print("%d : IN(%d)" % (n, train[i]))
                        n += 1
                        print("%d : PUSH(%d,%d)" % (n, 2, train[i]))
                        n += 1
                        i += 1
                    else:
                        s3.push(train[i])
                        print("%d : IN(%d)" % (n, train[i]))
                        n += 1
                        print("%d : PUSH(%d,%d)" % (n, 3, train[i]))
                        n += 1
                        i += 1
                else:
                    s1.push(train[i])
                    print("%d : IN(%d)" % (n, train[i]))
                    n += 1
                    print("%d : PUSH(%d,%d)" % (n, 1, train[i]))
                    n += 1
                    i += 1

    print("종료 (총 %d회)"%(n-1))