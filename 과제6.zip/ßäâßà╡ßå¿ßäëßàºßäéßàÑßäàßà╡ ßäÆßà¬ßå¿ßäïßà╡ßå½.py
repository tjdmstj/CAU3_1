re=[i*0 for i in range(26)]

Alph={"a":1,"b":2,"c":3,"d":4,"e":5,"f":6,"g":7,"h":8,"i":9,"j":10,
          "k":11,"l":12,"m":13,"n":14,"o":15,"p":16,"q":17,"r":18,"s":19,
          "t":20,"u":21,"v":22,"w":23,"x":24,"y":25,"z":26}

f=open("randdict.TXT","r")
Alphabet=list(Alph.keys())
for i in range(10):
    line = f.readline()
    if not line:
        break
    list=line.split(":")
    word=list[0].strip() #앞뒤로 공백을 제거해준다.
    mean=list[1].strip()
    for j in Alphabet:
        if j==word[0]:
            re[Alph[j]-1]+=1
            break
f.close()
print(re)