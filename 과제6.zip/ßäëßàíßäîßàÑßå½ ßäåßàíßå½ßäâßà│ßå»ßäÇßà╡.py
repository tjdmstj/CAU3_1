class Node:  #노드 만들기
  def __init__(self, word, mean, next=None):
      self.word = word
      self.mean = mean
      self.next = next

class LinkedList:  #연결 리스트 만들기
    def __init__(self):
        self.head = None
        self.len= 0

    def insert(self, word, mean):
        n_word=Node(word,mean)
        l_word=n_word.word.lower()  #소문자로 변환
        node=self.head
        if (node is None) or (node.word > l_word): #첫 노드와 이어질때( 이때 소문자로만 생각한다)
            n_word.next=self.head
            self.head=n_word
        else:  # 처음에 추가되지 않는 경우(반복문을 통해 단어가 들어가는 곳을 찾아야 한다)
            while (node.next is not None) and (node.next.word < l_word):
                node = node.next
            n_word.next=node.next
            node.next=n_word  #self.head를 쓸 수 없음으로
        self.len +=1

    #delete는 생략함 사전에서 빠지는 기능이 없기 때문
    '''
    def display(self):
        node = self.head
        while node is not None:
            print("%d : %d"%(node.word,node.mean))
            node = node.next
        print()
    '''
    def find_w(self,word_in): #word_in이 연결리스트 안에 있는지 확인함
        node=self.head
        while True:
            if node is None:
                return 0
            elif node.word == word_in:
                return node.mean
            node=node.next

f=open("randdict.TXT","r")
dic=LinkedList()
while True:
    line = f.readline()
    if not line:
        break
    list=line.split(":")
    word=list[0].strip() #앞뒤로 공백을 제거해준다.
    mean=list[1].strip()
    dic.insert(word,mean)

print("===개선하기 전===")
while True:
    word=input("단어 검색(검색하지 않으려면 Enter) >> ")
    if word=="": #공백을 입력하면 끝내기
        break
    else:
        a=dic.find_w(word)
        if a ==0:
            new_word=input("찾을 수 없는 단어입니다. 뜻을 추가하세요(추가하지 않으려면 공백) > ")
            if new_word=="":
                continue
            else:
                dic.insert(word,new_word)
                print("%s %s 가 추가되었습니다. (총 %d개 단어)" % (word, new_word, dic.len))
        else:
            print(">> %s"%a)


