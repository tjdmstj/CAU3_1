class Linkedlist2:
    def __init__(self):
        self.head2 = None
        self.len = 0

    def insert_w(self, word, mean):
        n_word = Node(word, mean)
        l_word = n_word.word.lower()  # 소문자로 변환
        w = l_word[0]  # a
        Alph = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8, "i": 9, "j": 10,
                "k": 11, "l": 12, "m": 13, "n": 14, "o": 15, "p": 16, "q": 17, "r": 18, "s": 19,
                "t": 20, "u": 21, "v": 22, "w": 23, "x": 24, "y": 25, "z": 26}  # 알파벳을 나타내는 딕셔너리

        node_a = self.head

        for i in range(Alph[w] - 1):  # 0번 반복
            node_a = node_a.next

        node_a.num = self.head2
        node = node_a.num
        if (node is None) or (node.word > l_word):  # 첫 노드와 이어질때(이때 소문자로만 생각한다)
            n_word.next = self.head2
            self.head = n_word
        else:  # 처음에 추가되지 않는 경우(반복문을 통해 단어가 들어가는 곳을 찾아야 한다)
            while (node.next is not None) and (node.next.word < n_word.word):
                node = node.next
            n_word.next = node.next
            node.next = n_word  # self.head를 쓸 수 없음으로
        self.len += 1

class LinkedList:  #연결 리스트 만들기
    def __init__(self):
        self.head = None
        self.len= 0

    def insert_a(self, al):    #알파벳으로 구성된 연결리스트 만드는 함수
        n_al=Node2(al)
        node=self.head
        if (node is None) or (node.al > n_al.al): #첫 노드와 이어질때
            n_al.next=self.head
            self.head=n_al
        else:  # 처음에 추가되지 않는 경우(반복문을 통해 단어가 들어가는 곳을 찾아야 한다)
            while (node.next is not None) and (node.next.al < n_al.al):
                node = node.next
            n_al.next=node.next
            node.next=n_al  #self.head를 쓸 수 없음으로
