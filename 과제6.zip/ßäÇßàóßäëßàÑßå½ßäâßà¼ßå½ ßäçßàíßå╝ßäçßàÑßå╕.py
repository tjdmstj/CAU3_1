class Node:  #노드 만들기
  def __init__(self, word, mean, next=None):
      self.word = word  #단어
      self.mean = mean  #뜻
      self.next = next  #주소


class LinkedList:  #연결 리스트 만들기
    def __init__(self):
        self.head = None
        self.len= 0

    def insert(self, word, mean):
        n_word=Node(word,mean)
        l_word=n_word.word.lower()  #소문자로 변환
        node=self.head
        if (node is None) or (node.word > l_word): #첫 노드와 이어질때( 이때 소문자로만 생각한다)
            n_word.next=self.head
            self.head=n_word
        else:  # 처음에 추가되지 않는 경우(반복문을 통해 단어가 들어가는 곳을 찾아야 한다)
            while (node.next is not None) and (node.next.word < l_word):
                node = node.next
            n_word.next=node.next
            node.next=n_word  #self.head를 쓸 수 없음으로
        self.len +=1


    def find_al(self,word_in,re): #word_in이 연결리스트 안에 있는지 확인함
        w=word_in[0]
        sum_s=0
        sum_f=0
        Alph = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8, "i": 9, "j": 10,
                "k": 11, "l": 12, "m": 13, "n": 14, "o": 15, "p": 16, "q": 17, "r": 18, "s": 19,
                "t": 20, "u": 21, "v": 22, "w": 23, "x": 24, "y": 25, "z": 26}


        for i in range(Alph[w]-1):  #시작 지점 찾기
            sum_s+=re[i]
        for i in range(Alph[w]): #끝나는 지점 찾기
            sum_f+=re[i]

        node = self.head
        for i in range(sum_s):
            node = node.next  #단어를 찾지 않고 알파벳 수만큼 건너뛰기

        for i in range(sum_f-sum_s):
            if node.word == word_in:
                return node.mean
            node=node.next

        return 0

    def display(self):
        node = self.head
        while node is not None:
            print("%s : %s" % (node.word, node.mean))
            node = node.next

#===================================================================================
Alph={"a":1,"b":2,"c":3,"d":4,"e":5,"f":6,"g":7,"h":8,"i":9,"j":10,
          "k":11,"l":12,"m":13,"n":14,"o":15,"p":16,"q":17,"r":18,"s":19,
          "t":20,"u":21,"v":22,"w":23,"x":24,"y":25,"z":26} #알파벳을 나타내는 딕셔너리

f=open("randdict.TXT","r")
dic_a=LinkedList()
Alphabet=list(Alph.keys())
re=[i*0 for i in range(26)]   # 알파벳의 개수를 알려주는 리스트 생성, 리스트에서 찾을 때 알파벳의 개수만큼 뛰어넘기

while True:
    line = f.readline()
    if not line:
        break
    list=line.split(":")
    word=list[0].strip() #앞뒤로 공백을 제거해준다.
    mean=list[1].strip()
    for j in Alphabet:
        if j==word[0]:
            re[Alph[j]-1]+=1
            break
    dic_a.insert(word, mean)
f.close()

Question=input("사전을 확인하시겠습니까?(Y/N)")
if Question=="Y":
    dic_a.display()

print("===개선 후===")
while True:
    word=input("단어 검색(검색하지 않으려면 Enter) >> ")
    if word=="": #공백을 입력하면 끝내기
        break
    else:
        a=dic_a.find_al(word,re)
        if a ==0:
            new_word=input("찾을 수 없는 단어입니다. 뜻을 추가하세요(추가하지 않으려면 공백) > ")
            if new_word=="":
                continue
            else:
                dic_a.insert(word,new_word)
                re[Alph[word[0]]-1]+=1
                print("%s %s 가 추가되었습니다. (총 %d개 단어)" % (word, new_word, dic_a.len))
        else:
            print(">> %s"%a)
