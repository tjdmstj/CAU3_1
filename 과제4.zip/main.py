#4-1 미로탐색
import copy

class Stack:
    def __init__(self):
        self.stack=[]
        self.top=-1

    def push(self,n):
        self.stack.append(n)
        self.top+=1

    def pop(self):
        if self.top!=-1:          # 스택이 비어있지 않다면
            self.top-=1
            return self.stack.pop()
        else:
            print("스택이 비었습니다.")

    def isEmpty(self):
        if self.top==-1:         #스택이 비어있다면
            return -1
        else:                    #스택이 비어있지 않다면
            return 0

    def peek(self):
        return self.stack[-1]
#====================================
def find_1(miro,width,height):
    s=Stack()
    c=Stack()
    check=[]
    for i in range(height):
        check.append([0]*width)          # 지나가지 않은 길 0 지나간 길 1

    x=1
    y=1
    s.push((1,1))
    check[1][1]=1
    print("PUSH(1,1)")
    while True:
        if s.isEmpty()==-1:
            return False
        c.push((y,x))
        if (y==width-2 and x==height-2):                     #만약 도착지에 도착했다면 반복분 중지
            return check
        if (miro[x-1][y]+miro[x][y-1]+miro[x][y+1]+miro[x+1][y])>=3: #미로탐색 우선순위(왼쪽, 위쪽, 아래쪽, 오른쪽)
            xy=list(s.peek())
            if miro[x][y-1]==1 and check[x][y-1]==0:           #왼쪽 확인 후 왼쪽으로 이동
                check[x][y-1]=1
                if (xy[0] == y and xy[1] == x):
                    y-=1
                    continue
                else:
                    s.push((y, x))
                    print("PUSH(%d,%d)"%(y,x))
                    y-=1
                continue
            elif miro[x-1][y]==1 and check[x-1][y]==0:         #위쪽 확인 후 위쪽으로 이동
                check[x-1][y] = 1
                if (xy[0] == y and xy[1] == x):
                    x -= 1
                    continue
                else:
                    s.push((y, x))
                    print("PUSH(%d,%d)" % (y, x))
                    x-=1
                continue
            elif miro[x+1][y]==1 and check[x+1][y]==0:         #아래쪽 확인 후 아래쪽으로 이동
                check[x+1][y]=1
                if (xy[0] == y and xy[1] == x):
                    x += 1
                    continue
                else:
                    s.push((y, x))
                    print("PUSH(%d,%d)" % (y, x))
                    x+=1
                continue
            elif miro[x][y+1]==1 and check[x][y+1]==0:         #오른쪽 확인 후 오른쪽으로 이동
                check[x][y+1]=1
                if (xy[0] == y and xy[1] == x):
                    y += 1
                    continue
                else:
                    s.push((y, x))
                    print("PUSH(%d,%d)" % (y, x))
                    y+=1
            else:                                            #미로의 길이 없는 경우

                xy = list(s.stack[-2])
                yy = xy[0]  # 7
                xx = xy[1]  # 19
                while True:
                    cc = list(c.peek())
                    yyy = cc[0]  # 1 2 3 4 5 6 7
                    xxx = cc[1]  # 19 20 21 22 23 22 21 20 19
                    if (yy == yyy and xx == xxx):
                        break
                    else:
                        check[xxx][yyy] = 2  # 들어갔따가 길이 없어서 다시 나옴
                        c.pop()

                xy = list(s.pop())
                y = xy[0]
                x = xy[1]
                print("POP(%d,%d)" % (y, x))
                xy = list(s.peek())  # x,y좌표 다시 설정
                y = xy[0]
                x = xy[1]

        elif (miro[x-1][y]+miro[x][y-1]+miro[x][y+1]+miro[x+1][y])==1:      #갈 수 있는 길이 막힘  ex) a= 7 b= 7

            xy=list(s.peek())
            yy=xy[0]     #7
            xx=xy[1]     #9
            while True:
                cc = list(c.peek())
                yyy = cc[0]  # 7
                xxx = cc[1]  # 7 8 9
                if (yy==yyy and xx==xxx):
                    break
                else:
                    check[xxx][yyy]=2 # 들어갔따가 길이 없어서 다시 나옴
                    c.pop()

            xy=list(s.peek())
            y = xy[0]   #7
            x = xy[1]   #9
            if miro[x][y-1]==1 and check[x][y-1]==0:           #왼쪽 확인 후 왼쪽으로 이동
                check[x][y-1]=1
                y-=1
                continue
            elif miro[x-1][y]==1 and check[x-1][y]==0:         #위쪽 확인 후 위쪽으로 이동
                check[x-1][y] = 1
                x-=1
                continue
            elif miro[x+1][y]==1 and check[x+1][y]==0:         #아래쪽 확인 후 아래쪽으로 이동
                check[x+1][y]=1
                x+=1
                continue
            elif miro[x][y+1]==1 and check[x][y+1]==0:         #오른쪽 확인 후 오른쪽으로 이동
                check[x][y+1]=1
                y+=1
                continue
            else:                                             #갈 수 있는 길이 없음
                xy=list(s.pop())
                y=xy[0]
                x=xy[1]
                print("POP(%d,%d)"%(y,x))
                xy = list(s.peek())                                 #x,y좌표 다시 설정
                y = xy[0]
                x = xy[1]
        else:                                                # 합한 것이 2일 때
            if miro[x][y-1]==1 and check[x][y-1]==0:           #왼쪽 확인 후 왼쪽으로 이동
                check[x][y-1]=1
                y-=1
                continue
            elif miro[x-1][y]==1 and check[x-1][y]==0:         #위쪽 확인 후 위쪽으로 이동
                check[x-1][y] = 1
                x-=1
                continue
            elif miro[x+1][y]==1 and check[x+1][y]==0:         #아래쪽 확인 후 아래쪽으로 이동
                check[x+1][y]=1
                x+=1
                continue
            elif miro[x][y+1]==1 and check[x][y+1]==0:         #오른쪽 확인 후 오른쪽으로 이동
                check[x][y+1]=1
                y+=1


#======================================================
def find_2(miro,width,height):
    s2=Stack()
    c2=Stack()
    check2=[]
    for i in range(height):
        check2.append([0]*width)          # 지나가지 않은 길 0 지나간 길 1

    x=1
    y=1
    s2.push((1,1))
    check2[1][1]=1
    print("PUSH(1,1)")

    if miro[0][1]+miro[1][0]+miro[1][2]+miro[2][1]==2:
        check2[2][1]=2
    else:
        return False

    while True:
        if s2.isEmpty()==-1:
            return False
        if len(c2.stack)>0 and x==1 and y==1:
            print("POP(1,1)")
            break
        c2.push((y,x))
        if (y==width-2 and x==height-2):                     #만약 도착지에 도착했다면 반복분 중지
            return check2
        if (miro[x-1][y]+miro[x][y-1]+miro[x][y+1]+miro[x+1][y])>=3: #미로탐색 우선순위(오른쪽, 위쪽, 아래쪽, 왼쪽)
            xy=list(s2.peek())
            if miro[x][y + 1] == 1 and check2[x][y + 1] == 0:  # 오른쪽 확인 후 오른쪽으로 이동
                check2[x][y + 1] = 1
                if (xy[0] == y and xy[1] == x):
                    y += 1
                    continue
                else:
                    s2.push((y, x))
                    print("PUSH(%d,%d)" % (y, x))
                    y += 1
                continue
            elif miro[x - 1][y] == 1 and check2[x - 1][y] == 0:  # 위쪽 확인 후 위쪽으로 이동
                check2[x - 1][y] = 1
                if (xy[0] == y and xy[1] == x):
                    x -= 1
                    continue
                else:
                    s2.push((y, x))
                    print("PUSH(%d,%d)" % (y, x))
                    x -= 1
                continue
            elif miro[x+1][y]==1 and check2[x+1][y]==0:         #아래쪽 확인 후 아래쪽으로 이동
                check2[x+1][y]=1
                if (xy[0] == y and xy[1] == x):
                    x += 1
                    continue
                else:
                    s2.push((y, x))
                    print("PUSH(%d,%d)" % (y, x))
                    x+=1
                continue
            elif miro[x][y-1]==1 and check2[x][y-1]==0:           #왼쪽 확인 후 왼쪽으로 이동
                check2[x][y-1]=1
                if (xy[0] == y and xy[1] == x):
                    y-=1
                    continue
                else:
                    s2.push((y, x))
                    print("PUSH(%d,%d)"%(y,x))
                    y-=1
            else:                                            #미로의 길이 없는 경우

                xy = list(s2.stack[-2])
                yy = xy[0]
                xx = xy[1]
                while True:
                    cc = list(c2.peek())
                    yyy = cc[0]
                    xxx = cc[1]
                    if (yy == yyy and xx == xxx):
                        break
                    else:
                        check2[xxx][yyy] = 2  # 들어갔따가 길이 없어서 다시 나옴
                        c2.pop()

                xy = list(s2.pop())
                y = xy[0]
                x = xy[1]
                print("POP(%d,%d)" % (y, x))
                xy = list(s2.peek())  # x,y좌표 다시 설정
                y = xy[0]
                x = xy[1]

        elif (miro[x-1][y]+miro[x][y-1]+miro[x][y+1]+miro[x+1][y])==1:      #갈 수 있는 길이 막힘  ex) a= 7 b= 7

            xy=list(s2.peek())
            yy=xy[0]     #7
            xx=xy[1]     #9
            while True:
                cc = list(c2.peek())
                yyy = cc[0]  # 7
                xxx = cc[1]  # 7 8 9
                if (yy==yyy and xx==xxx):
                    break
                else:
                    check2[xxx][yyy]=2 # 들어갔따가 길이 없어서 다시 나옴
                    c2.pop()

            xy=list(s2.peek())
            y = xy[0]   #7
            x = xy[1]   #9

            if miro[x][y+1]==1 and check2[x][y+1]==0:         #오른쪽 확인 후 오른쪽으로 이동
                check2[x][y+1]=1
                y+=1
                continue
            elif miro[x-1][y]==1 and check2[x-1][y]==0:         #위쪽 확인 후 위쪽으로 이동
                check2[x-1][y] = 1
                x-=1
                continue
            elif miro[x + 1][y] == 1 and check2[x + 1][y] == 0:  # 아래쪽 확인 후 아래쪽으로 이동
                check2[x + 1][y] = 1
                x += 1
                continue
            elif miro[x][y-1]==1 and check2[x][y-1]==0:           #왼쪽 확인 후 왼쪽으로 이동
                check2[x][y-1]=1
                y-=1
                continue
            else:                                             #갈 수 있는 길이 없음
                xy=list(s2.pop())
                y=xy[0]
                x=xy[1]
                print("POP(%d,%d)"%(y,x))
                xy = list(s2.peek())                                 #x,y좌표 다시 설정
                y = xy[0]
                x = xy[1]
        else:                                                # 합한 것이 2일 때
            if miro[x][y+1]==1 and check2[x][y+1]==0:         #오른쪽 확인 후 오른쪽으로 이동
                check2[x][y+1]=1
                y+=1
                continue
            elif miro[x-1][y]==1 and check2[x-1][y]==0:         #위쪽 확인 후 위쪽으로 이동
                check2[x-1][y] = 1
                x-=1
                continue
            elif miro[x+1][y]==1 and check2[x+1][y]==0:         #아래쪽 확인 후 아래쪽으로 이동
                check2[x+1][y]=1
                x+=1
                continue
            elif miro[x][y-1]==1 and check2[x][y-1]==0:           #왼쪽 확인 후 왼쪽으로 이동
                check2[x][y-1]=1
                y-=1



#======================================================

maze=input("미로번호를 선택하세요.(1,2,3) : ")
maze="maze"+maze+".txt"
f=open(maze,"r")
miro=[]
miro_c=[]
miro_c2=[]
array=f.readline()               #미로의 규격 읽어오기

if(array[1]==" "):
    w=int(array[0])
    if (array[3]==" "):
        h=int(array[2])
    else:
        h=int(array[2])*10+int(array[3])
else:
    w=int(array[0])*10+int(array[1])
    if (array[4] == " "):
        h = int(array[3])
    else:
        h = int(array[3]) * 10 + int(array[4])

height=2*h+1     #높이
width=2*w+1      #넓이

for i in range(height):
    line=f.readline()
    line=list(line)
    del line[width]     #\n 지움
    miro.append(line)
f.close()
miro_c=copy.deepcopy(miro)
miro_c2=copy.deepcopy(miro)

for i in range(height):                    # 출발좌표은(1,1) 도착좌표는 (width-1,height-1)
    for j in range(len(miro[i])):
        if miro[i][j] in "+-|":
            miro[i][j]=0                        # 0은 갈 수 없음(길이 없음)
        else:
            miro[i][j]=1                        # 1은 갈 수 있음(길이 있음)

#=====================================================================================
print("길 탐색 시작")

print("<첫번째 경로 출력>")
find_miro1=find_1(miro,width,height)
if not find_miro1:
    print("첫번째 경로가 없습니다.")
else:
    for i in range(height):
        for j in range(width):
            if find_miro1[i][j]==1:
                miro_c[i][j]="O"

    for i in range(height):
        line=""
        for j in range(width):
            line+=miro_c[i][j]
        print(line)

print("="*width)

print("<두번째 경로 출력>")
find_miro2=find_2(miro,width,height)
if not find_miro2:
    print("두번째 경로가 없습니다.")
else:
    for i in range(height):
        for j in range(width):
            if find_miro2[i][j]==1:
                miro_c2[i][j]="O"

    for i in range(height):
        line=""
        for j in range(width):
            line+=miro_c2[i][j]
        print(line)

