#4-2 큐 운영하기

class Queue:
    def __init__(self):
        self.front=0
        self.rear=0
        self.flag=0
        self.queue=[None]*20

    def isEmpty(self):
        if self.front==self.rear:
            return True
        else:
            return False

    def isFull(self):
        if (self.rear+1)%20==self.front:
            return True
        else:
            return False

    def addQ(self, n):
        if not self.isFull():
            self.rear=(self.rear+1)%20       #rear값 변경
            self.queue[self.rear]=n           #오류 수정 필요

    def deleteQ(self):
        if not self.isEmpty():
            self.front=(self.front+1)%20    #front값 변경
            return self.queue[self.front]

    def f(self):
        return self.front

    def r(self):
        return self.rear

    def show(self):                          #큐의 상태 보여주는 함수
        list=[]
        print("QUEUE = ",end="")
        for i in self.queue[self.front+1:self.rear+1]:
            if i ==None:
                continue
            else:
                list.append(i)
        if len(list)>0:
            for i in list:
                print(i,end=" ")
            print("(",len(list),")")
        else:
            print("(",len(list),")")

#============================================================

print("시스템이 시작됩니다.")
Q=Queue()
off=0
while True:
    if off==1:
        break
    Show=input(">>>")
    if Show== "0":
        Q.show()
    elif Show.isdigit():
        for i in range(int(Show)):
            if Q.isEmpty():
                print("DELETEQUEUE() = FAIL.QueueEmpty")
                off=1
                break
            else:
                print("DELETEQUEUE() =",Q.deleteQ(),end="")
                print("   F=",Q.f(), "R=", Q.r())
    else:
        Show=list(Show)
        for i in Show:
            if Q.isFull():
                print("(SYSTEM) ADDQUEUE() = FAIL.QueueFull")
                off=1
                break
            else:
                Q.addQ(i)
                print("(SYSTEM) ADDQUEUE(%c)"%i,end="")
                print("   F=",Q.f(), "R=", Q.r())
