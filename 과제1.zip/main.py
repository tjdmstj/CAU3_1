def make_maze(name):
    name+=".txt"

    f=open(name,"r")
    line=f.readline()
    array=list(line)

    if(array[1]==" "):
        w=int(array[0])
        if (array[3]==" "):
            h=int(array[2])
        else:
            h=int(array[2])*10+int(array[3])
    else:
        w=int(array[0])*10+int(array[1])
        if (array[4] == " "):
            h = int(array[3])
        else:
            h = int(array[3]) * 10 + int(array[4])
    height=2*h+1
    width=2*w+1

    maze=[]

    for i in range(h):
        line=f.readline()
        array=list(line)
        del array[width]
        line=f.readline()
        array.append(list(line))
        del array[width][width]

        for j in range(0,width,2):
            if(j==width-1):
                maze.append(2)
                break
            if(array[j+1]=="-" and array[width][j]==" "):
                maze.append(1)
            elif(array[j+1]==" " and array[width][j]=="|"):
                maze.append(2)
            elif(array[j+1]=="-" and array[width][j]=="|"):
                maze.append(3)
            else:
                maze.append(0)

    line=f.readline()
    array=list(line)
    del array[width]
    for j in range(0, width, 2):
        if (j == width - 1):
            maze.append(0)
            break
        if (array[j + 1] == "-" ):
            maze.append(1)
        elif (array[j + 1] == " "):
            maze.append(2)
        elif (array[j + 1] == "-"):
            maze.append(3)
        else:
            maze.append(0)

    return maze,width,height                    #미로 저장하는 함수 끝

def draw_maze(name,width,height):
    w=int((width+1)/2)    #ex) w=10
    h=int((height+1)/2)   #ex) h=13
    pmaze=[]          #출력을 위해 저장되는 리스트
    for i in range(len(name)-w):           # ex) len(maze)=130(마지막 줄은 따로 진행)
        if ((i+1)%w!=0):              # 마지막 열까지 처리 완료하면 홀수 행 추가하기 위한 조건문  ex)(i+1)%10!=0 10의 배수(넓이가 10)
            if (name[i]==1):
                if (name[i-1]==1 or name[i-1]==3):  # 가로비교
                    if(name[i-w]==2 or name[i-w]==3):
                        pmaze.append("+")
                        pmaze.append("-")
                    else:
                        pmaze.append("-")
                        pmaze.append("-")
                else:
                    pmaze.append("+")
                    pmaze.append("-")
            elif (name[i]==3):
                pmaze.append("+")
                pmaze.append("-")
            elif (name[i]==0):
                pmaze.append("+")
                pmaze.append(" ")
            else:                                      # 2일때
                if (name[i-w]==2 or name[i-w]==3):   # 세로비교
                    if(name[i-1]==1 or name[i-1]==3):
                        pmaze.append("+")
                        pmaze.append(" ")
                    else:
                        pmaze.append("|")
                        pmaze.append(" ")
                else:
                    pmaze.append("+")
                    pmaze.append(" ")

        else:                                           # 가장 마지막 열 w의 배수 일때
            if (name[i-1]==3 or name[i-1]==1):
                pmaze.append("+")
            else:
                pmaze.append("|")

            for j in range(1,w+1):                      # 짝수줄 추가하기 작업
                if (j%w!=0):
                    if (name[i-(w-j)]==3 or name[i-(w-j)]==2):
                        pmaze.append("|")
                        pmaze.append(" ")
                    else:
                        pmaze.append(" ")
                        pmaze.append(" ")
                else:
                    pmaze.append("|")

    for l in range(len(name)-w,len(name)):           #마지막 줄 추가하기
        if l==len(name)-1:
            pmaze.append("+")
            break
        if (name[l-w]==2 or name[l-w]==3):
            pmaze.append("+")
            pmaze.append("-")
        else:
            pmaze.append("-")
            pmaze.append("-")

    for h in range(len(pmaze)):              # 미로 프린트 return 값 없음
        if (h%width==0 and h!=0):
            print("\n")
        print(pmaze[h],end=" ")



name=input("what's the maze name?")
out=list(make_maze(name))
out_maze=out[0]
width=out[1]
height=out[2]
draw_maze(out_maze,width,height)


